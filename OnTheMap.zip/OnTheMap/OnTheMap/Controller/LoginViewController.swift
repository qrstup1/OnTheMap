//
//  LoginViewController.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 12/31/19.
//  Copyright © 2019 R&M. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var emailTextField: LoginTextField!
    @IBOutlet weak var passwordTextField: LoginTextField!
    @IBOutlet weak var loginFromUdacityButton: UIButton!
    @IBOutlet weak var loginActivityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setLoginReady(condition: true)
        

    }

    override func viewWillAppear(_ animated: Bool) {
        subscribeToKeyboardNotifications()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        //Function unsubscribes from monitoring when the view will disappear.
        
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    @IBAction func loginButtonPressed(_ sender: Any) {
        let username = emailTextField.text
        let password = passwordTextField.text
        setLoginReady(condition: false)
        UdacityLoginAPI.getSessionFromUdacity(username: username ?? "", password: password ?? "", completion: handleLoginResponse(sessionID:success:error:))
        
    }
    
    
    func handleLoginResponse(sessionID: String, success: Bool, error: Error?) {
        DispatchQueue.main.async {
            if success {
                UdacityClient.getStudentData()
                while UdacityClient.Students.groupOfTenStudents.count <= 9 {
                    //This is my method to ensure the map data available prior to segue.
                }
                self.segueToUserScreen()
                self.setLoginReady(condition: true)
            }
            else {
                self.showLoginFailure(message: error?.localizedDescription ?? "")
                self.setLoginReady(condition: true)
            }
        }
    }
    
    func segueToUserScreen() {
        let controller: TabViewController
        controller = storyboard?.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
        controller.modalPresentationStyle = .fullScreen
        present(controller, animated: true, completion: nil)
    }
    
    func showLoginFailure(message: String) {
        let alertVC = UIAlertController(title: "Login Failed", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        show(alertVC, sender: nil)
    }
    
    func subscribeToKeyboardNotifications() {
        //Function subscribes to the keyboard notifications.
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
           //function tracks for unsubscribing to the keyboard notifications.
           
           NotificationCenter.default.removeObserver(self)
           }
    
    @objc func keyboardWillShow(_ notification:Notification) {
           //This function determines if the top or bottom text field is active and shifts the view appropriately
        let keyboardSize = getKeyboardHeight(notification)
        if (keyboardSize > 112 && passwordTextField.isEditing) || (keyboardSize > 146 && emailTextField.isEditing){
            let shiftSize = keyboardSize - 112
            view.frame.origin.y = -shiftSize
        }
       }
       
       @objc func keyboardWillHide(_ notification:Notification) {
           //This function resets the origin of the view to the original 0 point.
           view.frame.origin.y = 0
       }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        // Function provides the keyboard height in the form of a Float to allow for adjusting the display the appropriate number to keep the bottom text on the screen.
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    func setLoginReady (condition: Bool) {
        loginActivityIndicator.isHidden = condition
        emailTextField.isEnabled = condition
        passwordTextField.isEnabled = condition
        loginFromUdacityButton.isEnabled = condition

        if condition {
            emailTextField.text = ""
            passwordTextField.text = ""
            loginActivityIndicator.stopAnimating()
        }
        else {
            loginActivityIndicator.startAnimating()
        }
    }
    

}
