//
//  UdacityResponses.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 1/2/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import Foundation

struct LoginResponse: Codable {
    
    let account: AccountInfo
    let session: SessionInfo
}

struct AccountInfo: Codable {
    let registered: Bool
    let key: String
}

struct SessionInfo: Codable {
    let id: String
    let expiration: String
}

struct AllStudentData: Codable{
    let results: [StudentData]
}

struct StudentData: Codable {
    let firstName: String
    let lastName: String
    let longitude: Float64
    let latitude: Float64
    let mapString: String
    let mediaURL: String
    let uniqueKey: String?
    let objectID: String?
    let createdAt: String
    let updatedAt: String
}
/*
 {"firstName":"John",
 "lastName":"Doe","longitude":-122.083851,"latitude":37.386052,"mapString":"Mountain View, CA","mediaURL":"https://udacity.com","uniqueKey":"1234","objectId":"ID13","createdAt":"2019-05-17T00:53:33.981Z","updatedAt":"2019-05-17T00:53:33.981Z"}
 
 struct AllStudentData: Codable{
     static var studentList: [StudentData] = []
 }

 struct StudentData: Codable {
     static var firstName: String = ""
     static var lastName: String = ""
     static var longitude: Float64 = 0.0
     static var latitude: Float64 = 0.0
     static var mapString: String = ""
     static var mediaURL: String = ""
     static var uniqueKey: String = ""
     static var objectID: String = ""
     static var createdAt: String = ""
     static var updatedAt: String = ""
 }

 */
