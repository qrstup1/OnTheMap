//
//  UdacityClient.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 1/8/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import Foundation
import UIKit



class UdacityClient {
    
    struct Students {
       
           static var groupOfTenStudents: [StudentData] = []
       }
    
    enum Endpoint  {
        case get10students

        
        var url: URL {
            return URL(string: self.stringValue)!
        }
        
        var stringValue: String {
            switch self {
            case .get10students:
                return "https://onthemap-api.udacity.com/v1/StudentLocation?limit=10"
            }
        }
    }

    class func getStudentData() {
        let request = URLRequest(url: Endpoint.get10students.url)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { // Handle error...
                return
            }
            do {
                let responseObject = try JSONDecoder().decode(AllStudentData.self, from: data!)
                
                    self.Students.groupOfTenStudents = responseObject.results
            
 //               print(responseObject.results)
            }
            catch{
                print("That decode didn't work")
                print(error)
            }
              /*
                let newData = data?.subdata(in: range) /* subset response data! */
                 let responseObject = try JSONDecoder().decode(LoginResponse.self, from: newData!)
                 DispatchQueue.main.async {
                     if responseObject.account.key != "" {
                         self.session.id = responseObject.session.id
                         self.session.expiration = responseObject.session.expiration
                         self.session.uniqueKey = responseObject.account.key
                         completion(responseObject.session.id, true, nil)
                    }
                     else {
                         completion("None",false, error)
                     }
 //                    Auth.key = responseObject.account.key
 //                    Auth.sessionId = responseObject.session.id
                     //completion(true, nil)
                 }

             } catch {
                 print("Unable to decode")
                 print(error)
                 completion("None", false, error)
             }

            */
            
            
 //           print(String(data: data!, encoding: .utf8)!)
        }
        task.resume()

        
    }

}

/*
 class func requestRandomImage(breed: String, completionHandler: @escaping (DogImage?, Error?) -> Void){
     let randomImageEndpoint = DogAPI.Endpoint.randomImageForBreed(breed).url
     let task = URLSession.shared.dataTask(with: randomImageEndpoint) {(data, response, error) in
             guard let data = data else {
                 completionHandler(nil, error)
                 print("data was nil")
                 return}
             print(data)
             let decoder = JSONDecoder()
             do {
                 let imageData = try decoder.decode(DogImage.self, from: data)
                 print(imageData)
                 completionHandler(imageData, nil)
    
             }
             catch
             {
                 completionHandler(nil, error)
                 print("imageData empty")
                 return
             }
         }
         task.resume()
 }
 */
