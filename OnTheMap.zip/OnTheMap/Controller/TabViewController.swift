//
//  TabViewController.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 1/6/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import Foundation
import UIKit

class TabViewController: UITabBarController {


    override func viewDidLoad() {
        super.viewDidLoad()
 //       TODO: Consider deleting this file
    }
    
    
}

