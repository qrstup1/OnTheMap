//
//  NewPinViewController.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 2/11/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import CoreLocation

import Foundation
import UIKit

class NewPinViewController: UIViewController {

    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var urlTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //TODO: Disable add pin button.

    }


    
    @IBAction func checkLocation(_ sender: Any) {
        
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(locationTextField!.text!) { (placemarks, error) in
            guard
                let placemarks = placemarks,
                let location = placemarks.first?.location,
                let name = placemarks.first?.name
                //TODO: This is where I stopped. Neet to get the name of the location from post geocode processes to make sure it is correct.
                //TODO: Need to update the mapvies as a zoomed in look at the location.
                else {
                    // handle no location found
                    return
            }
            //TODO: Zoom map into location.coordinate.
            //TODO: Enable add pin
            UdacityClient.UserData.latitude = location.coordinate.latitude
            UdacityClient.UserData.longitude = location.coordinate.longitude
            UdacityClient.UserData.locationName = (name)
            print(UdacityClient.UserData.locationName)
            print(location.coordinate)
            
        }
    }
    
    @IBAction func cancelAddPin(_ sender: Any) {
        DispatchQueue.main.async {
        self.dismiss(animated: true, completion: nil)
    }
    
    
}
    
    @IBAction func logoutButton(_ sender: Any) {
         UdacityLogoutAPI.logoutFromUdacity {
             DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
                
                //TODO: FIX THE LOGOUT - This will only resign the NewPinViewController and not the tab view
             }
         }
     }
    
    @IBAction func addNewPin(_ sender: Any) {
        print("ADD PIN")
        UdacityClient.UserData.mediaURL = self.urlTextField.text ?? " "
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation")!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"uniqueKey\": \"1234\", \"firstName\": \"\(UdacityClient.UserData.firstName)\", \"lastName\": \"\(UdacityClient.UserData.lastName)\",\"mapString\": \"Mountain View, CA\", \"mediaURL\": \"\(UdacityClient.UserData.mediaURL)\",\"latitude\": \"\(UdacityClient.UserData.latitude)\", \"longitude\": \"\(UdacityClient.UserData.longitude)\"}".data(using: .utf8)
        

        

        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
          if error != nil { // Handle error…
              return
          }
          print(String(data: data!, encoding: .utf8)!)
        }
        task.resume()

        DispatchQueue.main.async {
            self.dismiss(animated: true, completion: nil)
        }



    }



}


