//
//  ListViewController.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 1/7/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import Foundation

import UIKit

class ListViewController: UITableViewController, UINavigationControllerDelegate {

    let cellReuseIdentifier = "StudentTableViewCell"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return UdacityClient.Students.groupOfTenStudents.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         
         let cell =  tableView.dequeueReusableCell(withIdentifier: self.cellReuseIdentifier)!
        let student = UdacityClient.Students.groupOfTenStudents[(indexPath as NSIndexPath).row]
        cell.textLabel?.text = student.firstName + " " + student.lastName
        cell.detailTextLabel?.text = student.mediaURL
         
         return cell
     }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let student = UdacityClient.Students.groupOfTenStudents[(indexPath as NSIndexPath).row]
        guard let newURL = URL(string: student.mediaURL)
            else { return }
        print(newURL)
        if UIApplication.shared.canOpenURL(newURL) {
       UIApplication.shared.open(newURL)
        } else {
            print("URL Failed")
            //TODO: Add Alert view for this failure
            return
        }
        
    }
    
    
    @IBAction func addPinButton(_ sender: Any) {
        print("ADD PIN")
        print("ADD PIN")
        print(UdacityClient.UserData.firstName)
        self.newPinSegue()
    }
    
    @IBAction func logoutButton(_ sender: Any) {
       UdacityLogoutAPI.logoutFromUdacity {
            DispatchQueue.main.async {
                self.dismiss(animated: true, completion: nil)
            }
            
        }
    }
    
    func newPinSegue() {
            let controller: NewPinViewController
            controller = storyboard?.instantiateViewController(withIdentifier: "NewPinViewController") as! NewPinViewController
            controller.modalPresentationStyle = .fullScreen
            present(controller, animated: true, completion: nil)
        }

}
