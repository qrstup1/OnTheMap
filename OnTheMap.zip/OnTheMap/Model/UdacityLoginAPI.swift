//
//  UdacityLoginAPI.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 1/1/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import Foundation
import UIKit

class UdacityLoginAPI {
    
    struct session: Codable{
    
        static var id: String = ""
        static var expiration: String = ""
        static var uniqueKey: String = ""
    }
    
    enum Endpoint  {
        case udacityLogin
        case facebookLogin
        
        var url: URL {
            return URL(string: self.stringValue)!
        }
        
        var stringValue: String {
            switch self {
            case .udacityLogin:
                return "https://onthemap-api.udacity.com/v1/session"
            case .facebookLogin:
                return "https://onthemap-api.udacity.com/v1/session"

                
            }
        }
    }
    
    class func getSessionFromUdacity(username: String, password: String, completion: @escaping (String, Bool, Error?) -> Void) {
        var request = URLRequest(url: Endpoint.udacityLogin.url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        // encoding a JSON body from a string, can also use a Codable struct
        request.httpBody = "{\"udacity\": {\"username\": \"\(username)\", \"password\": \"\(password)\"}}".data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            do{
                let range = 5..<data!.count
                let newData = data?.subdata(in: range) /* subset response data! */
                let responseObject = try JSONDecoder().decode(LoginResponse.self, from: newData!)
                DispatchQueue.main.async {
                    if responseObject.account.key != "" {
                        self.session.id = responseObject.session.id
                        self.session.expiration = responseObject.session.expiration
                        self.session.uniqueKey = responseObject.account.key
                        completion(responseObject.session.id, true, nil)
                   }
                    else {
                        completion("None",false, error)
                    }
//                    Auth.key = responseObject.account.key
//                    Auth.sessionId = responseObject.session.id
                    //completion(true, nil)
                }

            } catch {
                print("Unable to decode")
                print(error)
                completion("None", false, error)
            }
            
        }
        task.resume()
    }
    
}

