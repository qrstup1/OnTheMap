//
//  UdacityClient.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 1/8/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import Foundation
import UIKit



class UdacityClient {
    
    struct Students {
       
           static var groupOfTenStudents: [StudentData] = []
       }
    
    enum Endpoint  {
        case get10students
        case getUserData

        
        var url: URL {
            return URL(string: self.stringValue)!
        }
        
        var stringValue: String {
            switch self {
            case .get10students:
                return "https://onthemap-api.udacity.com/v1/StudentLocation?limit=10"
            case .getUserData:
                return "https://onthemap-api.udacity.com/v1/users/3903878747"
            }
        }
    }

    
    class func getUserData() {
        let request = URLRequest(url: Endpoint.getUserData.url)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { // Handle error...
                return
            }
            let range = 5..<data!.count
            let newData = data?.subdata(in: range) /* subset response data! */
            print(String(data: newData!, encoding: .utf8)!)
            do{
                
                let responseObject = try JSONDecoder().decode(IndividualUser.self, from: data!)
                print(responseObject)
                
                
            }
            catch{
                print("Get UserData didn't work")
                print(error)
            }
        }
        task.resume()
        
    }

    class func getStudentData() {
        let request = URLRequest(url: Endpoint.get10students.url)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { // Handle error...
                return
            }
                print(String(data: data!, encoding: .utf8)!)
            do {
                let responseObject = try JSONDecoder().decode(AllStudentData.self, from: data!)
                print(responseObject.results)
                    self.Students.groupOfTenStudents = responseObject.results
            
            }
            catch{
                print("That decode didn't work")
                print(error)
            }

        }
        task.resume()

        
    }

}

