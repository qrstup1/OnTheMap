//
//  UdacityLogoutAPI.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 1/7/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import Foundation
import UIKit

class UdacityLogoutAPI {
    
    
    enum Endpoint  {
        case udacityLogout
        case facebookLogout
        
        var url: URL {
            return URL(string: self.stringValue)!
        }
        
        var stringValue: String {
            switch self {
            case .udacityLogout:
                return "https://onthemap-api.udacity.com/v1/session"
            case .facebookLogout:
                return "https://onthemap-api.udacity.com/v1/session"
                
            }
        }
    }
    
    class func logoutFromUdacity(completion: @escaping ()-> Void) {
        var request = URLRequest(url: Endpoint.udacityLogout.url)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
          if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
          request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
          if error != nil { // Handle error…
              return
          }
            UdacityLoginAPI.session.id = ""
            UdacityLoginAPI.session.expiration = ""
            
            completion()
        }
        task.resume()

    }
    
}
