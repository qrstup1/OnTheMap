//
//  UdacityResponses.swift
//  OnTheMap
//
//  Created by Rob and Megan Low on 1/2/20.
//  Copyright © 2020 R&M. All rights reserved.
//

import Foundation

struct LoginResponse: Codable {
    
    let account: AccountInfo
    let session: SessionInfo
}

struct AccountInfo: Codable {
    let registered: Bool
    let key: String
}

struct SessionInfo: Codable {
    let id: String
    let expiration: String
}

struct AllStudentData: Codable{
    let results: [StudentData]
}

struct StudentData: Codable {
    let firstName: String
    let lastName: String
    let longitude: Float64
    let latitude: Float64
    let mapString: String
    let mediaURL: String
    let uniqueKey: String?
    let objectID: String?
    let createdAt: String
    let updatedAt: String
}

struct IndividualUser: Codable {
    let last_name: String?
    let social_accounts: [String?]
    let mailing_address: String?
    let _cohort_keys: [String?]
    let signature: String?
    let _stripe_customer_id: String?
    let `guard`: [String?] //This may not work
    let _facebook_id: String?
    let timezone: String?
    let site_preferences: String?
    let occupation: String?
    let _image: String?
    let first_name: String?
    let jabber_id: String?
    let languages: String?
    let _badges: [String?]
    let location: String?
    let external_service_password: String?
    let _principals: [String?]
    let _enrollments: [String?]
    let email: [String?: String?]
    let website_url: String?
    let external_accounts: String?
    let bio: String?
    let coaching_data: String?
    let tags: [String?]
    let _affiliate_profiles: [String?]
    let _has_password: Bool?
    let email_preferences: String?
    let _resume: String?
    let key: String?
    let nickname: String?
    let employer_sharing: Bool?
    let _memberships: [String]
    let zendesk_id: String?
    let _registered: Bool?
    let linkedin_url: String?
    let _google_id: String?
    let _image_url: String?
}

